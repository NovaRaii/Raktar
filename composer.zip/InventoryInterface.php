<?php

interface InventoryInterface
{
    public function create(array $data) : ?int;
}

