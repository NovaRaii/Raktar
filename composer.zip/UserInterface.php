<?php

interface UserInterface
{
    public function create(array $data) : ?int;
}

