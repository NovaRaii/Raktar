<?php

interface ShelvesInterface
{
    public function create(array $data) : ?int;
}

