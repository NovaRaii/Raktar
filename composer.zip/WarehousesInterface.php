<?php

interface WarehousesInterface
{
    public function create(array $data) : ?int;
}

